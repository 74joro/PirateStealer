---
name: Feature Suggest
about: Purpose your feature / Publish your code here
title: 'Purpose your feature'
labels: ''
assignees: ''

---

#  Note
I will check your code/idea and if it's good I will invite you as contributor and publish it/code it and publish it by mentioning your github name. 

# Rules
- Do not post obfuscated code.
- Do not publish any code containing a webhook link, it may be that people seeing this request delete/spam
- Do not put dox / nsfw content
- Do not steal existing code unless you have mentioned the original creator.
