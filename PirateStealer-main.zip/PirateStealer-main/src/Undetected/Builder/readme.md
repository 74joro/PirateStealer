### Undetected Builder

Written in golang


git clone project
navigate here
then exec in cmd the followings:
```bash
go mod tidy
go build
./Builder.exe
```
